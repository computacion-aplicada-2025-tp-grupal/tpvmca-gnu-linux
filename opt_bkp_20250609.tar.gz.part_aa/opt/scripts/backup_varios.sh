#!/bin/bash
# filepath: backup_varios.sh

# Lista de directorios a respaldar individualmente
DIRS=("/root" "/etc" "/opt" "/proc" "/www_dir" "/backup_dir" "/var")

# Fecha en formato ANSI
DATE=$(date +"%Y%m%d")

# Directorio de destino para los backups
DEST="/backup_dir"
mkdir -p "$DEST"

# Backup individual de cada directorio, spliteado en partes de 20MB
for DIR in "${DIRS[@]}"; do
    BASENAME=$(basename "$DIR")
    BACKUP_FILE="${DEST}/${BASENAME}_bkp_${DATE}.tar.gz"
    # Excluir /proc/kcore si el directorio es /proc
    if [[ "$DIR" == "/proc" ]]; then
        tar -czvf - --exclude='/proc/kcore' -C "$(dirname "$DIR")" "$BASENAME" | split -b 20m - "${BACKUP_FILE}.part_"
    else
        tar -czvf - -C "$(dirname "$DIR")" "$BASENAME" | split -b 20m - "${BACKUP_FILE}.part_"
    fi
    echo "Backup de $DIR creado y spliteado en partes de 20MB en: ${BACKUP_FILE}.part_*"
done
