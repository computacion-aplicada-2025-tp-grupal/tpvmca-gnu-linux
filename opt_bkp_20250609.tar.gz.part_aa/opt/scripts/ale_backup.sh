#!/bin/bash
# filepath: backup_full.sh

check_fs_available() {
    local DIR="$1"
    if ! mountpoint -q "$DIR" && ! findmnt -rn -o TARGET --target "$DIR" >/dev/null; then
        echo "Error: El sistema de archivos para '$DIR' no está disponible o no se encuentra montado."
        exit 2
    fi
}

show_help() {
    echo "Uso: $0 [directorio_origen] [directorio_destino]"
    echo "Ejemplo: $0 /etc /backup_dir"
}

if [[ "$1" == "-h" || "$1" == "--help" ]]; then
    show_help
    exit 0
fi


ORIGEN="${1}"
DESTINO="${2}"

check_fs_available "$ORIGEN"
check_fs_available "$DESTINO"

# Fecha en formato ANSI
DATE=$(date +"%Y%m%d")

# Nombre base del directorio origen
BASENAME=$(basename "$ORIGEN")
BACKUP_FILE="${DESTINO}/${BASENAME}_bkp_${DATE}.tar.gz"

# Crear el directorio de destino si no existe
mkdir -p "$DESTINO"

# Crear el backup
tar -czvf "$BACKUP_FILE" -C "$(dirname "$ORIGEN")" "$BASENAME"
echo "Backup de $ORIGEN creado en: $BACKUP_FILE"

