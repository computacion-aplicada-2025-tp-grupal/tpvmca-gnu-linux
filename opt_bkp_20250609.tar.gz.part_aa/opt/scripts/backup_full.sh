#!/bin/bash

if [[ "$1" == "-help" || "$#" -ne 2 ]]; then
    echo "Comando de uso: $0 <carpeta_fuente> <carpeta_destino>"
    echo "Ejemplo: $0 /etc /backup_dir"
    echo "Nota: El destino debe ser /backup_dir o un subdirectorio."
else
    FUENTE=$1
    DESTINO=$2
    FECHA_ACTUAL=$(date +%Y%m%d)

    # Validar que el destino sea /backup_dir o subdirectorio
    if [[ "$DESTINO" != /backup_dir* ]]; then
        echo "Error: El destino debe ser /backup_dir o un subdirectorio de /backup_dir."
        exit 1
    fi

    if [ -d "$FUENTE" ]; then
        echo "La carpeta fuente $FUENTE está disponible."
        if [ -d "$DESTINO" ]; then
            echo "La carpeta destino $DESTINO está disponible."

            ARCHIVO_RESPLD=$(basename "$FUENTE")_bkp_${FECHA_ACTUAL}.tar.gz

            /bin/tar -cpzvf "${DESTINO}/${ARCHIVO_RESPLD}" "$FUENTE"
            if [ $? -eq 0 ]; then
                echo "Respaldo de $FUENTE realizado exitosamente en ${DESTINO}/${ARCHIVO_RESPLD}." >> /var/log/respaldoTP.log
                echo "Respaldo de $FUENTE realizado exitosamente en ${DESTINO}/${ARCHIVO_RESPLD}."
            else
                echo "Fallo al crear el respaldo de $FUENTE, fecha $FECHA_ACTUAL" >> /var/log/respaldoTP.log
            fi
        else
            echo "Error: La carpeta destino $DESTINO no existe o no está disponible."
            echo "Fallo al crear el respaldo, fecha $FECHA_ACTUAL, la carpeta destino $DESTINO no existe o no está disponible." >> /var/log/respaldoTP.log
        fi
    else
        echo "Error: La carpeta fuente $FUENTE no existe o no está disponible."
        echo "Fallo al crear el respaldo, fecha $FECHA_ACTUAL, la carpeta fuente $FUENTE no existe o no está disponible." >> /var/log/respaldoTP.log
    fi
fi


